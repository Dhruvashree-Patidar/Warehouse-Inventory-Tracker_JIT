public interface StockObserver 
{
	void onLowStock(Product p);
}
